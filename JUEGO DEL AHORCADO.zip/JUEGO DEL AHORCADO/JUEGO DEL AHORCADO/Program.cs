﻿using System;

namespace JUEGO_DEL_AHORCADO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String[] palabras = { "BATMAN", "SUPERMAN", "SPIDERMAN", "DARTH VADER", "HULK", "LOS VENGADORES", "IRON MAN", "CAPITAN AMERICA", };
            Random generador = new Random();
            int numeroazar = generador.Next(0, palabras.Length);
            String palabrasadivinar = palabras[numeroazar];


            String palabramostrar = "";
            for (int i = 0; i < palabrasadivinar.Length; i++)
                if (palabrasadivinar[i] == ' ')
                    palabramostrar += " ";
                else
                    palabramostrar += "-";


            int fallosrestantes = 8;
            char letraactual;
            bool terminado = false;


            do
            {
                Console.WriteLine("Palabra Oculta: " + palabramostrar);
                Console.WriteLine("Fallos Restantes: " + fallosrestantes);

                Console.WriteLine("Introduzca Una Letra: ");
                letraactual = Convert.ToChar(Console.ReadLine());


                if (!palabrasadivinar.Contains(letraactual))
                {
                    fallosrestantes--;
                    mostraralahorcado(fallosrestantes);
                }


                String siguientemostrar = "";

                for(int i = 0; i < palabrasadivinar.Length; i++)
                {
                    if (letraactual == palabrasadivinar[i])
                        siguientemostrar += letraactual;
                    else
                        siguientemostrar += palabramostrar[i];
                }
                palabramostrar = siguientemostrar;




                if (!palabramostrar.Contains("-"))
                {
                    Console.WriteLine("Felicidades Si Le Atinaste ({0})",
                        palabrasadivinar);
                    terminado = true;
                }
                else if (fallosrestantes == 0)
                {
                    Console.WriteLine("Lo siento era" +" "+ palabrasadivinar + " " + "Pero que la fuerza te acompañe");
                    terminado = true;
                }


            }
            while (!terminado);
        }
        static void mostraralahorcado(int fallosrestantes)
        {
            switch(fallosrestantes)
            {
                case 7:
                    Console.WriteLine("-");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 6:
                    Console.WriteLine("-------");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 5:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 4:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|    O");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 3:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|    O");
                    Console.WriteLine("|   /|");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 2:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|    O");
                    Console.WriteLine("|   /|\\");
                    Console.WriteLine("|");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 1:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|    O");
                    Console.WriteLine("|   /|\\");
                    Console.WriteLine("|   / ");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
                case 0:
                    Console.WriteLine("-------");
                    Console.WriteLine("|    |");
                    Console.WriteLine("|    O");
                    Console.WriteLine("|   /|\\");
                    Console.WriteLine("|   / \\");
                    Console.WriteLine("|");
                    Console.WriteLine("----");
                    break;
            }


        }
    }
}
    
